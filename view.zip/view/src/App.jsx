
import './App.css'
import UserDetailsForm from './pages/userform'

function App() {

  return (
    <>
    <UserDetailsForm/>
        
    </>
  )
}

export default App
